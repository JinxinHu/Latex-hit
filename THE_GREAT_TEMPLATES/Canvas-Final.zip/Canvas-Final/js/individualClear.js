﻿function delR(id){
document.getElementById("r_"+id).value=0;
document.getElementById("s_"+id).value=0;
document.getElementById("t_"+id).value=0;
document.getElementById("u_"+id).value=0;
document.getElementById("retangularname_"+id).value="";
document.getElementById("retangularColor_"+id).value="black";
}
function del(id){
document.getElementById("a_"+id).value=0;
document.getElementById("b_"+id).value=0;
document.getElementById("c_"+id).value=0;
document.getElementById("d_"+id).value=0;
document.getElementById("linename_"+id).value="";
document.getElementById("lineColor_"+id).value="black";
}
function delC(id){
document.getElementById("e_"+id).value=0;
document.getElementById("f_"+id).value=0;
document.getElementById("g_"+id).value=0;
document.getElementById("h_"+id).value=0;
document.getElementById("i_"+id).value=0;
document.getElementById("j_"+id).value=0;
document.getElementById("k_"+id).value=0;
document.getElementById("l_"+id).value=0;
document.getElementById("curvename_"+id).value="";
document.getElementById("curvecolor_"+id).value="black";
}